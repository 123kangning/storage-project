#!/bin/bash

killall apiServer
killall dataServer
