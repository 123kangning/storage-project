package types

type LocateMessage struct {
	Addr string
	Id   int
}
